package com.example.listview;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Activity_ListView extends AppCompatActivity {


	ListView my_listview;
	ArrayList<String> spinnerSort = new ArrayList<>();
	customAdapter adapter;
	ArrayList<BikeData> arrayList = new ArrayList<>();
	String url = "http://www.tetonsoftware.com/bikes/bikes.json";
	JSONArray jsonArray;
	JSONHelper helperActivity;

	private static final int NUMB_PROJECTS_UNDEFINED = -1;
	private static final String BIKES = "Bikes";
	private static final String TAG = "JSONHelper";
	private static final String COMPANY = "Company";
	private static final String MODEL = "Model";
	private static final String PRICE = "Price";
	private static final String LOCATION = "Location";
	private static final String DATE = "Date";
	private static final String DESCRIPTION = "Description";
	private static final String PICTURE = "Picture";
	private static final String LINK = "Link";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// Change title to indicate sort by
		setTitle("Sort by:");

		//listview that you will operate on
		my_listview = (ListView)findViewById(R.id.lv);



		//custom adapter
		DownloadTask myTask = new DownloadTask(this);
		myTask.execute(url);

		//ask george to do this on his copy


		//toolbar
		Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		android.support.v7.app.ActionBar actionBar = getSupportActionBar();

		spinnerSort.add("Company");
		spinnerSort.add("Location");
		spinnerSort.add("Price");
		setupSimpleSpinner();

		//set the listview onclick listener
		setupListViewOnClickListener();

		//TODO call a thread to get the JSON list of bikes
		//TODO when it returns it should process this data with bindData
	}

	private void setJSON(int i) {
		jsonArray = new JSONArray();
		if(jsonArray == null){
			return;
		}

		try{
			JSONObject jsonObject = jsonArray.getJSONObject(i);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void setupListViewOnClickListener() {

		//TODO you want to call my_listviews setOnItemClickListener with a new instance of android.widget.AdapterView.OnItemClickListener() {
	}

	/**
	 * Takes the string of bikes, parses it using JSONHelper
	 * Sets the adapter with this list using a custom row layout and an instance of the CustomAdapter
	 * binds the adapter to the Listview using setAdapter
	 *
	 * @param JSONString  complete string of all bikes
	 */
	public void bindData(String JSONString) {

		arrayList = (ArrayList<BikeData>) this.parseAll(JSONString);
		adapter = new customAdapter(Activity_ListView.this, R.layout.listview_row_layout, arrayList);
		my_listview.setAdapter(adapter);

	}

	Spinner spinner;

	private void setupSimpleSpinner() {
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Activity_ListView.this, R.layout.spinner_item, spinnerSort);
		spinner = (Spinner) findViewById(R.id.spinner);
		spinner.setAdapter(dataAdapter);

		spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			public static final int SELECTED_ITEM = 0;

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				if (parent.getChildAt(SELECTED_ITEM) != null) {
					((TextView) parent.getChildAt(SELECTED_ITEM)).setTextColor(Color.WHITE);
					Toast.makeText(Activity_ListView.this, (String) parent.getItemAtPosition(position), Toast.LENGTH_LONG).show();

					//This is where we will sort the list view
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {

			}
		});
	}

	public List<BikeData> parseAll(String jsonString) {
		//list of all the bikes
		List<BikeData> myList = new ArrayList<BikeData>();

		try {
			JSONObject jAll = new JSONObject(jsonString);

			//get the raw array of bikes
			JSONArray jo = (JSONArray) jAll.get(BIKES);
			//UserData mydata = new UserData.Builder(first,last).addProject(proj1).addProject(proj2).build()

			//how many bikes?
			int numbBikes = jo.length();
			Log.d(TAG, "Number of bikes=" + Integer.toString(numbBikes));

			for (int i = 0; i < numbBikes; ++i) {
				JSONObject rec = jo.getJSONObject(i);

				//first add the mandatory fields
				BikeData.Builder myDataBuilder = new BikeData.Builder(rec.getString(COMPANY), rec.getString(MODEL), rec.getDouble(PRICE))
						.setLocation(rec.getString(LOCATION))
						.setDate(rec.getString(DATE))
						.setDescription(rec.getString(DESCRIPTION))
						.setPicture(rec.getString(PICTURE))
						.setLink(rec.getString(LINK));
				myList.add(myDataBuilder.build());
				//arrayList.add(myDataBuilder.build());
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return myList;
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

			default:
				break;
		}
		return true;
	}
}
