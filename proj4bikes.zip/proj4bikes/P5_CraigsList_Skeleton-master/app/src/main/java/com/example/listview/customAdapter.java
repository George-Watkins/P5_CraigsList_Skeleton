package com.example.listview;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Collections;
import java.util.List;


public class customAdapter extends BaseAdapter{
    Context context;

    public static final int COMPANY = 0;
    public static final int LOCATION = 1;
    public static final int PRICE = 2;

    List<BikeData> rowItems;
    LayoutInflater myInflater;
    String url = "http://www.tetonsoftware.com/bikes/";
    private Activity_ListView mainAc;

    public customAdapter(Context context, int resource, List<BikeData> rowItems){
        this.rowItems = rowItems;
        this.context = context;
    }

    public customAdapter(Activity_ListView activity){
        this.mainAc = activity;
        myInflater = (LayoutInflater)mainAc.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public class ViewHolder {
        ImageView thumbNail;
        TextView  tvDescription;
        TextView  tvTitle;
        TextView  tvPrice;
        public int position;
    }
    public void sortList(int iSort) {
        switch (iSort) {
            case COMPANY:
                Collections.sort(rowItems, new ComparatorModelCompany());
                break;
            case LOCATION:
                Collections.sort(rowItems, new ComparatorModelLocation());
                break;
            case PRICE:
                Collections.sort(rowItems, new ComparatorModelPrice());
                break;
            default:
                Collections.sort(rowItems, new ComparatorModelCompany());
                break;
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return rowItems.size();
    }

    @Override
    public Object getItem(int position) {
        return rowItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = new ViewHolder();

        holder.position = position;

        myInflater = (LayoutInflater)context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        if(convertView == null){
            convertView = myInflater.inflate(R.layout.listview_row_layout, null);
            holder = new ViewHolder();
            holder.tvDescription = (TextView)convertView.findViewById(R.id.Description);
            holder.tvTitle       = (TextView)convertView.findViewById(R.id.Title);
            holder.tvPrice       = (TextView)convertView.findViewById(R.id.Price);
            holder.thumbNail     = (ImageView)convertView.findViewById(R.id.thumbnail);
            convertView.setTag(holder);
        }
        else{
            holder = (ViewHolder)convertView.getTag();
        }

        BikeData bikeData = (BikeData) getItem(position);
        String price = "";
        price = String.valueOf(bikeData.PRICE);


        holder.tvDescription.setText(bikeData.DESCRIPTION);
        holder.tvTitle.setText(bikeData.MODEL);
        holder.tvPrice.setText("$"+price);
        //holder.thumbNail.setImageResource(R.drawable.bike3);  //bike3 is a preset image.  Need to fix this still.

        new DownloadImageTask(holder.position,holder.thumbNail,holder).execute(url+bikeData.PICTURE);
        //new thumbNailTask(holder.position,holder).execute(url);


        return convertView;
    }
}
